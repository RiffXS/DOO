package model.operations;

public class Subtraction implements IOperation {
    @Override
    public float operation(float a, float b) {
        return a - b;
    }
}
