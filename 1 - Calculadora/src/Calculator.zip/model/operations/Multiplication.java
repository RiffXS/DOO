package model.operations;

public class Multiplication implements IOperation {
    @Override
    public float operation(float a, float b) {
        return a * b;
    }
}
