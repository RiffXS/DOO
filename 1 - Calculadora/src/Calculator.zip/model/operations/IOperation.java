package model.operations;

public interface IOperation {
    float operation(float a, float b);
}
