package model.dto;

public class ResponseDTO {

    float result;

    public ResponseDTO(float result) {
        this.result = result;
    }

    public float getResult() {
        return result;
    }

    public void setResult(float result) {
        this.result = result;
    }

}
