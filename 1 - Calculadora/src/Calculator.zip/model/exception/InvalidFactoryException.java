package model.exception;

public class InvalidFactoryException extends RuntimeException {
  public InvalidFactoryException(String message) {
    super(message);
  }
}
